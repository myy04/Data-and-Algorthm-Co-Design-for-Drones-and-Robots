from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
import json
import time

from maze import Maze
from solver_agent import SolverAgent


MODEL_LIST = [
    'rnj-1:8b-cloud',
    'gemma4:31b-cloud',
    'gemma3:4b-cloud',
    'gemma3:12b-cloud',
    "ministral-3:3b-cloud",
    "ministral-3:8b-cloud",
    "ministral-3:14b-cloud"
]

MAZE_SIZES = [10, 15, 20]
MAX_PARALLEL_MODELS = 3
TRIALS = 50
RETRY_DELAY_SECONDS = 2
DATA_ROOT = Path(__file__).resolve().parent / "data"


def _empty_model_stats():
    return {size: {"tried": 0, "success": 0} for size in MAZE_SIZES}


def count_solved_mazes():
    """Count tried/solved mazes per model and maze size from existing result files."""
    counter = {model: _empty_model_stats() for model in MODEL_LIST}

    for model_dir in sorted(p for p in DATA_ROOT.iterdir() if p.is_dir()):
        for json_file in sorted(model_dir.glob("*.json")):
            try:
                with json_file.open("r", encoding="utf-8") as f:
                    data = json.load(f)
            except (json.JSONDecodeError, OSError):
                print(f"Error reading {json_file}")
                continue

            model = data.get("model") or data.get("solver agent") or model_dir.name
            if model not in counter:
                counter[model] = _empty_model_stats()

            try:
                maze_size = int(data.get("n"))
            except (TypeError, ValueError):
                continue

            if maze_size not in MAZE_SIZES:
                continue

            counter[model][maze_size]["tried"] += 1
            if bool(data.get("goal reached")):
                counter[model][maze_size]["success"] += 1

    return counter


def run_model(model: str):
    agent = SolverAgent(model)
    solve_rates = []

    for maze_size in MAZE_SIZES:
        while counter[model][maze_size]["tried"] < TRIALS:
            maze = Maze(wall_chance=50, n=maze_size, m=maze_size)
            while True:
                try:
                    solved = agent.solve_maze(maze, save_results=True)
                    break
                except Exception as exc:
                    print(
                        f"Model: {model} | Maze Size: {maze_size} | "
                        f"attempt failed with error: {exc}. Retrying..."
                    )
                    # Recreate the client before retrying in case connection state is bad.
                    agent = SolverAgent(model)
                    time.sleep(RETRY_DELAY_SECONDS)

            counter[model][maze_size]["tried"] += 1
            if solved:
                counter[model][maze_size]["success"] += 1

            print(f"Model: {model} | Maze Size: {maze_size} | {counter[model][maze_size]['tried']}/{TRIALS}")

        tried = counter[model][maze_size]["tried"]
        success = counter[model][maze_size]["success"]
        solve_rate = (success / tried) * 100.0 if tried else 0.0
        solve_rates.append((maze_size, solve_rate))

    return model, solve_rates


def main():
    global counter

    counter = count_solved_mazes()

    print("Target attempts per maze size:")
    for maze_size in MAZE_SIZES:
        print(f"{maze_size}x{maze_size}: {TRIALS}")

    with ThreadPoolExecutor(max_workers=MAX_PARALLEL_MODELS) as executor:
        futures = [executor.submit(run_model, model) for model in MODEL_LIST]

        for future in as_completed(futures):
            model, solve_rates = future.result()
            for maze_size, solve_rate in solve_rates:
                print(f"Model: {model} | Maze Size: {maze_size} | Finished with solve rate: {solve_rate}")


if __name__ == "__main__":
    main()