
from openai import OpenAI
# from maze import Maze
from pathlib import Path
from datetime import datetime
from copy import deepcopy

import json

class SolverAgent:      
    def __init__(self, model: str):
        self._client =  OpenAI(
            base_url="http://localhost:11434/v1",
            api_key="ollama",
            timeout = 120.0
        )
        self.model = model

        prompt_path = Path(__file__).resolve().parent / "system_prompt.txt"
        with prompt_path.open('r') as system_prompt_file:
            self._system_prompt = str(system_prompt_file.read())

    def ask_for_moves(self, maze_state, illegal_move_warning=None):
        prompt = f"Your position: {maze_state['player position']}\nGoal position: {maze_state['goal position']}\nMaze:\n{maze_state['maze']}"   
        if illegal_move_warning != None:
            prompt += "\n" + illegal_move_warning

        # print(prompt)

        response = self._client.chat.completions.create(
            model = self.model,
            messages =
            [{'role': 'system', 'content': self._system_prompt}] 
            +
            [{'role': 'user', 'content': prompt}],
            extra_body = {'think': False}
        )

        moves = response.choices[0].message.content
        # print(f"Moves: {moves}")
        return moves

    def solve_maze(self, maze, max_iterations = 10, save_results = False):          
        for iter in range(max_iterations):
            maze_state = maze.get_state()
            if maze_state['goal reached'] == True: break
            moves = str(self.ask_for_moves(maze_state, illegal_move_warning=None))
            maze.make_moves(moves)

        final_state = maze.get_state()
        if save_results:
            data = final_state
            data['model'] = self.model
            data['solver agent'] = self.model 

            timestamp = datetime.now().strftime("%m%d%H%M%S")

            model_dir = Path(__file__).resolve().parent / "data" / self.model
            model_dir.mkdir(parents=True, exist_ok=True)

            output_file = f"{timestamp}_{self.model}.json"
            output_path = model_dir / output_file

            with output_path.open("w", encoding="utf-8") as f:
                json.dump(data, f, indent=2, ensure_ascii=False)

            print(f"Saved state to {output_path}")
        return final_state['goal reached']

if __name__ == "__main__":
    from maze import Maze
    maze = Maze()
    agent = SolverAgent("rnj-1:8b-cloud")
    agent.solve_maze(maze, save_results=False)
    print(maze.get_state()['goal reached'])
    print(maze.get_state()['maze'])