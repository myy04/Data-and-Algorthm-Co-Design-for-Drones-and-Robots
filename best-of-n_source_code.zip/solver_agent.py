
import os
import re
import threading
import time
from pathlib import Path

from ollama import Client, ResponseError


class SolverAgent:      
    _api_key_lock = threading.Lock()
    _api_key_index = 0

    def __init__(self, model: str, temperature = 0.4):
        self.model = model
        self.temperature = temperature
        self.timeout = self._read_float_env("OLLAMA_TIMEOUT_SECONDS", 240.0)
        self.request_retry_rounds = self._read_int_env("OLLAMA_REQUEST_RETRY_ROUNDS", 1)
        self.disable_thinking = self._read_bool_env("OLLAMA_DISABLE_THINKING", True)
        self.base_url = os.getenv("OLLAMA_BASE_URL", "https://ollama.com").rstrip("/")
        self.client_host = self._normalize_client_host(self.base_url)
        self.api_keys = self._load_api_keys()

        prompt_path = Path(__file__).resolve().parent / "solver_agent_system_prompt.txt"
        with prompt_path.open('r') as system_prompt_file:
            self._system_prompt = str(system_prompt_file.read())

    def _read_float_env(self, name, default_value):
        raw_value = os.getenv(name, "").strip()
        if not raw_value:
            return default_value

        try:
            return float(raw_value)
        except ValueError:
            print(f"Invalid {name}='{raw_value}'. Using default {default_value}.")
            return default_value

    def _read_int_env(self, name, default_value):
        raw_value = os.getenv(name, "").strip()
        if not raw_value:
            return default_value

        try:
            parsed_value = int(raw_value)
        except ValueError:
            print(f"Invalid {name}='{raw_value}'. Using default {default_value}.")
            return default_value

        return max(0, parsed_value)

    def _read_bool_env(self, name, default_value):
        raw_value = os.getenv(name, "").strip().lower()
        if not raw_value:
            return default_value

        if raw_value in {"1", "true", "yes", "on"}:
            return True
        if raw_value in {"0", "false", "no", "off"}:
            return False

        print(f"Invalid {name}='{raw_value}'. Using default {default_value}.")
        return default_value

    def _load_api_keys(self):
        keys = []

        env_api_keys = os.getenv("OLLAMA_API_KEYS", "").strip()
        if env_api_keys:
            keys.extend([k.strip() for k in env_api_keys.split(",") if k.strip()])

        env_api_key = os.getenv("OLLAMA_API_KEY", "").strip()
        if env_api_key:
            keys.append(env_api_key)

        key_path = Path(__file__).resolve().parent / "ollama_api_key.txt"
        if key_path.exists():
            file_lines = key_path.read_text(encoding="utf-8").splitlines()
            for line in file_lines:
                line = line.strip()
                if not line or line.startswith("#"):
                    continue

                if ":" in line:
                    _, line = line.split(":", 1)

                parsed_key = line.strip()
                if parsed_key:
                    keys.append(parsed_key)

        deduped_keys = []
        seen = set()
        for key in keys:
            if key in seen:
                continue
            seen.add(key)
            deduped_keys.append(key)

        return deduped_keys

    def _api_key_candidates(self):
        if not self.api_keys:
            return [("none", None)]

        total_keys = len(self.api_keys)
        if total_keys == 1:
            return [("1/1", self.api_keys[0])]

        with SolverAgent._api_key_lock:
            start_index = SolverAgent._api_key_index % total_keys
            SolverAgent._api_key_index += 1

        candidates = []
        for offset in range(total_keys):
            key_index = (start_index + offset) % total_keys
            key_slot = f"{key_index + 1}/{total_keys}"
            candidates.append((key_slot, self.api_keys[key_index]))

        return candidates

    def _build_headers(self, api_key):
        headers = {}
        if api_key:
            headers["Authorization"] = f"Bearer {api_key}"
        return headers

    def _normalize_client_host(self, base_url):
        if base_url.endswith("/api"):
            return base_url[:-4]
        return base_url

    def _strip_thinking_markup(self, content):
        cleaned = re.sub(r"<think>.*?</think>", "", content, flags=re.IGNORECASE | re.DOTALL)
        lower_cleaned = cleaned.lower()
        close_idx = lower_cleaned.rfind("</think>")
        if close_idx != -1:
            cleaned = cleaned[close_idx + len("</think>"):]
        return cleaned.strip()

    def _extract_content(self, response):
        if isinstance(response, dict):
            return response.get("message", {}).get("content")

        message = getattr(response, "message", None)
        if message is None:
            return None

        if isinstance(message, dict):
            return message.get("content")

        return getattr(message, "content", None)

    def _request_chat(self, messages, think_enabled=None):
        key_candidates = self._api_key_candidates()
        retryable_http_codes = {408, 429, 500, 502, 503, 504}
        last_error = None

        for round_index in range(self.request_retry_rounds + 1):
            for key_slot, api_key in key_candidates:
                client = Client(host=self.client_host, headers=self._build_headers(api_key))

                request_kwargs = {
                    "model": self.model,
                    "messages": messages,
                    "stream": False,
                    "options": {"temperature": self.temperature},
                }
                if think_enabled is not None:
                    request_kwargs["think"] = think_enabled

                try:
                    return client.chat(**request_kwargs)
                except TimeoutError as exc:
                    last_error = TimeoutError(
                        f"Timeout while calling model '{self.model}' via key slot {key_slot}."
                    )
                except ResponseError as exc:
                    status_code = getattr(exc, "status_code", None)
                    error_body = getattr(exc, "error", str(exc))
                    should_try_next_key = status_code in {400, 401, 403} and len(key_candidates) > 1
                    should_retry_round = status_code in retryable_http_codes and round_index < self.request_retry_rounds

                    if should_try_next_key or should_retry_round:
                        last_error = RuntimeError(
                            f"HTTP {status_code} from Ollama for model '{self.model}' via key slot {key_slot}: {error_body}"
                        )
                        continue

                    raise RuntimeError(
                        f"HTTP {status_code} from Ollama for model '{self.model}' via key slot {key_slot}: {error_body}"
                    ) from exc
                except Exception as exc:
                    exc_text = str(exc).lower()
                    if "timeout" in exc_text or "timed out" in exc_text:
                        last_error = TimeoutError(
                            f"Timeout while calling model '{self.model}' via key slot {key_slot}."
                        )
                    else:
                        last_error = RuntimeError(
                            f"Network error while calling model '{self.model}' via key slot {key_slot}: {exc}"
                        )

            if round_index < self.request_retry_rounds:
                time.sleep(min(0.5 * (round_index + 1), 2.0))

        if last_error:
            raise last_error

        raise RuntimeError(f"Unknown error while calling model '{self.model}'.")

    def ask_for_moves(self, maze_state):
        prompt = f"Your position: {maze_state['player position']}\nGoal position: {maze_state['goal position']}\nMaze:\n{maze_state['maze']}"

        messages = [
            {"role": "system", "content": self._system_prompt},
            {"role": "user", "content": prompt},
        ]

        try:
            response_body = self._request_chat(messages, think_enabled=not self.disable_thinking)
        except RuntimeError as exc:
            # Some endpoints/models may reject the "think" field. Retry once without it.
            if self.disable_thinking and "HTTP 400" in str(exc) and "think" in str(exc).lower():
                response_body = self._request_chat(messages, think_enabled=None)
            else:
                raise

        content = self._extract_content(response_body)

        if not isinstance(content, str):
            raise RuntimeError(
                f"Invalid response from Ollama for model '{self.model}': {response_body}"
            )

        if self.disable_thinking:
            content = self._strip_thinking_markup(content)

        return content

if __name__ == "__main__":
    from maze import Maze
    maze = Maze()
    agent = SolverAgent("rnj-1:8b-cloud")
    agent.solve_maze(maze, save_results=False)
    print(maze.get_state()['goal reached'])
    print(maze.get_state()['maze'])