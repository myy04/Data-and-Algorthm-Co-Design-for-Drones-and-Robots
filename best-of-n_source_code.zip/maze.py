import random
import time
from copy import deepcopy

class Maze:
    def _legal_pos(self, x, y): 
        if x <= 0 or x >= self.n or y <= 0 or y >= self.m:
            return False
        if self.matrix[x][y] == '#':
            return False
        return True

    def _get_possible_path(self):
        path = [self.player_pos]    
        
        cur_x = self.player_pos[0]
        cur_y = self.player_pos[1]
        goal_x = self.goal_pos[0]
        goal_y = self.goal_pos[1]

        while [cur_x, cur_y] != [goal_x, goal_y]:
            if cur_x < goal_x:
                cur_x += 1
            elif cur_x > goal_x:
                cur_x -= 1
            elif cur_y < goal_y:
                cur_y += 1
            elif cur_y > goal_y:
                cur_y -= 1
            path += [[cur_x, cur_y]]

        return path

    def _generate_walls(self):
        self.walls = []

        for i in range(self.m):
            self.walls += [[0, i]]
            self.walls += [[self.n - 1, i]]

        for i in range(self.n): 
            self.walls += [[i, 0]]
            self.walls += [[i, self.m - 1]]

        possible_path = self._get_possible_path()
        for i in range(1, self.n):
            for j in range(1, self.m):
                if [i, j] == self.player_pos or [i, j] == self.goal_pos or [i, j] in possible_path: continue
                if random.randint(0, 100) < self.wall_chance:
                    self.walls += [[i, j]]
        
        return self.walls

    def _update_matrix(self):
        for i in range(self.n):
            for j in range(self.m):
                if [i, j] in self.walls:
                    self.matrix[i][j] = '#'
                elif [i, j] == self.player_pos:
                    self.matrix[i][j] = 'P'
                elif [i, j] == self.goal_pos:
                    self.matrix[i][j] = 'G'
                else:
                    self.matrix[i][j] = '*'

    def _shortest_path(self):
        from collections import deque

        q = deque([(self.player_pos[0], self.player_pos[1], 0)])
        directions = [(-1, 0), (1, 0), (0, -1), (0, 1)]
        visited = {tuple(self.player_pos)}

        while q:
            x, y, dist = q.popleft()

            for dx, dy in directions:
                nx, ny = x + dx, y + dy
                if self._legal_pos(nx, ny) == False or (nx, ny) in visited: continue    
                if [nx, ny] == self.goal_pos:
                    return dist + 1

                visited.add((nx, ny))  
                q.append((nx, ny, dist + 1))
        
        raise "The Goal is Unreachable"

    def __init__(self, wall_chance=50, n=10, m=10):
        self.wall_chance = wall_chance
        self.n = n
        self.m = m

        self.matrix = [['*' for i in range(self.m)] for j in range(self.n)]
        self.player_pos = [random.randint(1, self.n - 2), random.randint(1, self.m - 2)]
        self.goal_pos = [random.randint(1, self.n - 2), random.randint(1, self.m - 2)]
        while self.goal_pos == self.player_pos:
            self.goal_pos = [random.randint(1, self.n - 2), random.randint(1, self.m - 2)]
        self._generate_walls()
        self._update_matrix()

        self.moves_made = 0
        self.iterations = 0
        self.illegal_moves = 0
        self.shortest_dist = self._shortest_path()


    def show_env(self):
        print('-' * (self.m + 2))
        
        for i in range(self.n):
            print('|', end = '')
            for j in range(self.m): 
                print(self.matrix[i][j], end = '')
            print('|')
        
        print('-' * (self.m + 2))
        
    def make_moves(self, moves):
        self.iterations += 1
        
        old_player_pos = deepcopy(self.player_pos)
        illegal_move_idx = None

        for idx, move in enumerate(moves):  
            match move:
                case 'L':
                    if self._legal_pos(self.player_pos[0], self.player_pos[1] - 1) == False:
                        self.illegal_moves += 1
                        illegal_move_idx = idx
                        break
                    else: self.player_pos[1] -= 1
                case 'R':
                    if self._legal_pos(self.player_pos[0], self.player_pos[1] + 1) == False:
                        self.illegal_moves += 1
                        illegal_move_idx = idx
                        break
                    else: self.player_pos[1] += 1
                case 'U':
                    if self._legal_pos(self.player_pos[0] - 1, self.player_pos[1]) == False:
                        self.illegal_moves += 1
                        illegal_move_idx = idx
                        break
                    else: self.player_pos[0] -= 1
                case 'D':
                    if self._legal_pos(self.player_pos[0] + 1, self.player_pos[1]) == False:
                        self.illegal_moves += 1
                        illegal_move_idx = idx
                        break
                    else: self.player_pos[0] += 1
                case _:
                    self.illegal_moves += 1
                    illegal_move_idx = idx
                    break

            self.moves_made += 1

        self.matrix[old_player_pos[0]][old_player_pos[1]] = '*'
        self.matrix[self.player_pos[0]][self.player_pos[1]] = 'P'

        return illegal_move_idx

    def get_state(self): 
        state = {}
        
        state['n'] = self.n
        state['m'] = self.m
        state['wall chance'] = self.wall_chance
        state['player position'] = self.player_pos
        state['goal position'] = self.goal_pos
        state['goal reached'] = bool(self.player_pos == self.goal_pos) 
        state['iterations'] = self.iterations
        state['moves made'] = self.moves_made
        state['illegal moves'] = self.illegal_moves
        state['shortest distance'] = self.shortest_dist

        state['maze'] = ""
        for row in self.matrix:
            for elem in row:
                state['maze'] += elem
            state['maze'] += '\n'


        return state

    def __repr__(self):
        return self.get_state()['maze']

        
