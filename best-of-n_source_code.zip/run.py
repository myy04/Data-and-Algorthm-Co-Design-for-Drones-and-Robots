from concurrent.futures import FIRST_COMPLETED, ThreadPoolExecutor, wait

from tree import Tree
from maze import Maze

import json
import os
from pathlib import Path
import time



MODEL_LIST = [
    "rnj-1:8b-cloud",
    "gemma3:4b-cloud",
    "gemma3:12b-cloud",
    "ministral-3:3b-cloud",
    "ministral-3:8b-cloud",
    "ministral-3:14b-cloud",
]

REWARD_MODEL_LIST = [
    "deterministic-v1"
]

MAZE_SIZES = [10, 15, 20]


def _read_parallel_models_per_key(default_value=3):
    raw_value = os.getenv("PARALLEL_MODELS_PER_KEY", "").strip()
    if not raw_value:
        return default_value

    try:
        parsed_value = int(raw_value)
    except ValueError:
        print(f"Invalid PARALLEL_MODELS_PER_KEY='{raw_value}'. Using default {default_value}.")
        return default_value

    return max(1, parsed_value)


def _read_ollama_api_keys():
    keys = []

    env_api_keys = os.getenv("OLLAMA_API_KEYS", "").strip()
    if env_api_keys:
        keys.extend([k.strip() for k in env_api_keys.split(",") if k.strip()])

    env_api_key = os.getenv("OLLAMA_API_KEY", "").strip()
    if env_api_key:
        keys.append(env_api_key)

    key_path = Path(__file__).resolve().parent / "ollama_api_key.txt"
    if key_path.exists():
        for line in key_path.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if not line or line.startswith("#"):
                continue

            if ":" in line:
                _, line = line.split(":", 1)

            parsed_key = line.strip()
            if parsed_key:
                keys.append(parsed_key)

    deduped_keys = []
    seen = set()
    for key in keys:
        if key in seen:
            continue
        seen.add(key)
        deduped_keys.append(key)

    return deduped_keys


def _read_ollama_base_url():
    return os.getenv("OLLAMA_BASE_URL", "https://ollama.com").rstrip("/")


def _build_chat_endpoint(base_url):
    if base_url.endswith("/api"):
        return f"{base_url}/chat"
    return f"{base_url}/api/chat"


def _compute_default_parallel_models():
    key_count = len(_read_ollama_api_keys())
    parallel_models_per_key = _read_parallel_models_per_key(default_value=3)

    if key_count <= 0:
        key_count = 1

    return key_count * parallel_models_per_key


def _read_max_parallel_models():
    default_value = _compute_default_parallel_models()
    raw_value = os.getenv("MAX_PARALLEL_MODELS", "").strip()
    if not raw_value:
        return default_value

    try:
        parsed_value = int(raw_value)
    except ValueError:
        print(f"Invalid MAX_PARALLEL_MODELS='{raw_value}'. Using default {default_value}.")
        return default_value

    return max(1, parsed_value)


def _read_int_env(name, default_value, min_value=0):
    raw_value = os.getenv(name, "").strip()
    if not raw_value:
        return default_value

    try:
        parsed_value = int(raw_value)
    except ValueError:
        print(f"Invalid {name}='{raw_value}'. Using default {default_value}.")
        return default_value

    return max(min_value, parsed_value)


def _read_float_env(name, default_value, min_value=0.0):
    raw_value = os.getenv(name, "").strip()
    if not raw_value:
        return default_value

    try:
        parsed_value = float(raw_value)
    except ValueError:
        print(f"Invalid {name}='{raw_value}'. Using default {default_value}.")
        return default_value

    return max(min_value, parsed_value)


def _is_transient_infra_error(exc):
    text = str(exc).lower()
    transient_markers = [
        "http 408 from ollama",
        "http 429 from ollama",
        "http 500 from ollama",
        "http 502 from ollama",
        "http 503 from ollama",
        "http 504 from ollama",
        "timeout while calling model",
        "network error while calling model",
        "the read operation timed out",
    ]
    return any(marker in text for marker in transient_markers)


def _print_startup_config():
    api_keys = _read_ollama_api_keys()
    detected_key_count = len(api_keys)
    effective_key_count = detected_key_count if detected_key_count > 0 else 1
    parallel_models_per_key = _read_parallel_models_per_key(default_value=3)
    computed_default_parallel = effective_key_count * parallel_models_per_key
    base_url = _read_ollama_base_url()
    chat_endpoint = _build_chat_endpoint(base_url)
    using_override = bool(os.getenv("MAX_PARALLEL_MODELS", "").strip())
    timeout_seconds = os.getenv("OLLAMA_TIMEOUT_SECONDS", "240")
    request_retry_rounds = os.getenv("OLLAMA_REQUEST_RETRY_ROUNDS", "1")
    reward_cooldown_base = os.getenv("OLLAMA_TRANSIENT_MODEL_COOLDOWN_BASE_SECONDS", "3.0")
    reward_cooldown_multiplier = os.getenv("OLLAMA_TRANSIENT_MODEL_COOLDOWN_MULTIPLIER", "2.0")
    reward_cooldown_max = os.getenv("OLLAMA_TRANSIENT_MODEL_COOLDOWN_MAX_SECONDS", "60.0")

    print("=== Runtime Configuration ===")
    print(f"Ollama base URL: {base_url}")
    print(f"Ollama chat endpoint: {chat_endpoint}")
    print(f"Detected API keys: {detected_key_count}")
    print(f"Solver models: {len(MODEL_LIST)}")
    print(f"Reward strategies: {len(REWARD_MODEL_LIST)}")
    print(f"Total model pairs: {len(MODEL_LIST) * len(REWARD_MODEL_LIST)}")
    print(f"Parallel models per key: {parallel_models_per_key}")
    print(f"Computed default max parallel models: {computed_default_parallel}")
    print(f"Effective max parallel models: {MAX_PARALLEL_MODELS}")
    print(f"MAX_PARALLEL_MODELS override active: {using_override}")
    print(f"OLLAMA_TIMEOUT_SECONDS: {timeout_seconds}")
    print(f"OLLAMA_REQUEST_RETRY_ROUNDS: {request_retry_rounds}")
    print(f"OLLAMA_TRANSIENT_MODEL_COOLDOWN_BASE_SECONDS: {reward_cooldown_base}")
    print(f"OLLAMA_TRANSIENT_MODEL_COOLDOWN_MULTIPLIER: {reward_cooldown_multiplier}")
    print(f"OLLAMA_TRANSIENT_MODEL_COOLDOWN_MAX_SECONDS: {reward_cooldown_max}")
    print(f"MAX_TRANSIENT_INFRA_RETRIES_PER_MAZE: {MAX_TRANSIENT_INFRA_RETRIES_PER_MAZE}")
    print(f"TRANSIENT_INFRA_BACKOFF_BASE_SECONDS: {TRANSIENT_INFRA_BACKOFF_BASE_SECONDS}")
    print(f"TRANSIENT_INFRA_BACKOFF_MULTIPLIER: {TRANSIENT_INFRA_BACKOFF_MULTIPLIER}")
    print(f"TRANSIENT_INFRA_BACKOFF_MAX_SECONDS: {TRANSIENT_INFRA_BACKOFF_MAX_SECONDS}")

    if detected_key_count == 0:
        print("Warning: no API keys detected from env or ollama_api_key.txt")

    print("============================")


MAX_PARALLEL_MODELS = _read_max_parallel_models()
MAX_MODEL_RETRIES = 2
MAX_ATTEMPTS_PER_MAZE = 3
MAX_MODEL_ATTEMPTS = 1 + MAX_MODEL_RETRIES
MAX_TRANSIENT_INFRA_RETRIES_PER_MAZE = _read_int_env("MAX_TRANSIENT_INFRA_RETRIES_PER_MAZE", 5, min_value=0)
TRANSIENT_INFRA_BACKOFF_BASE_SECONDS = _read_float_env("TRANSIENT_INFRA_BACKOFF_BASE_SECONDS", 5.0, min_value=0.0)
TRANSIENT_INFRA_BACKOFF_MULTIPLIER = _read_float_env("TRANSIENT_INFRA_BACKOFF_MULTIPLIER", 1.8, min_value=1.0)
TRANSIENT_INFRA_BACKOFF_MAX_SECONDS = _read_float_env("TRANSIENT_INFRA_BACKOFF_MAX_SECONDS", 60.0, min_value=0.0)


def count_solved_mazes():
    """Count the number of mazes solved by each (solver, reward) pair."""
    counter = {}
    
    data_dir = './data/'
    
    MAZE_SIZES = [10, 15, 20]

    # Iterate through all JSON files in ./data/
    for filename in os.listdir(data_dir):
        if filename.endswith('.json'):
            filepath = os.path.join(data_dir, filename)
            
            try:
                with open(filepath, 'r') as f:
                    data = json.load(f)
                    solver_model = data.get('solver agent')
                    reward_model = data.get('reward agent', solver_model)
                    maze_size = int(data.get('n'))

                    if solver_model not in counter.keys():
                        counter[solver_model] = {}

                    if reward_model not in counter[solver_model].keys():
                        counter[solver_model][reward_model] = {}
                        for n in MAZE_SIZES:
                            counter[solver_model][reward_model][n] = {}
                            counter[solver_model][reward_model][n]['tried'] = 0
                            counter[solver_model][reward_model][n]['success'] = 0

                    counter[solver_model][reward_model][maze_size]['tried'] += 1
                    if bool(data.get('goal reached')) == True:
                        counter[solver_model][reward_model][maze_size]['success'] += 1


            except (json.JSONDecodeError, TypeError, ValueError):
                print(f"Error reading {filepath}")

    return counter

def run_model(solver_model: str, reward_model: str):
    TRIALS = 20

    solve_rates = []

    for maze_size in MAZE_SIZES:
        transient_retry_count = 0

        while counter[solver_model][reward_model][maze_size]['tried'] < TRIALS:
            solved = False
            had_error = False
            all_errors_transient = True

            for attempt in range(1, MAX_ATTEMPTS_PER_MAZE + 1):
                try:
                    maze = Maze(n=maze_size, m=maze_size)
                    tree = Tree(solver_agent=solver_model, reward_agent=reward_model)
                    solved = tree.solve_maze(maze)
                    break
                except Exception as exc:
                    had_error = True
                    if not _is_transient_infra_error(exc):
                        all_errors_transient = False

                    print(
                        f"Solver: {solver_model} | Reward: {reward_model} | Maze Size: {maze_size} | "
                        f"Attempt: {attempt}/{MAX_ATTEMPTS_PER_MAZE} | "
                        f"Error: {type(exc).__name__}: {exc}"
                    )

            if (not solved) and had_error and all_errors_transient:
                if transient_retry_count < MAX_TRANSIENT_INFRA_RETRIES_PER_MAZE:
                    transient_retry_count += 1
                    delay_seconds = min(
                        TRANSIENT_INFRA_BACKOFF_BASE_SECONDS
                        * (TRANSIENT_INFRA_BACKOFF_MULTIPLIER ** (transient_retry_count - 1)),
                        TRANSIENT_INFRA_BACKOFF_MAX_SECONDS,
                    )
                    print(
                        f"Solver: {solver_model} | Reward: {reward_model} | Maze Size: {maze_size} | "
                        f"Transient provider failure detected. Trial not counted. "
                        f"Backing off for {delay_seconds:.1f}s "
                        f"({transient_retry_count}/{MAX_TRANSIENT_INFRA_RETRIES_PER_MAZE})."
                    )

                    if delay_seconds > 0:
                        time.sleep(delay_seconds)
                    continue

                print(
                    f"Solver: {solver_model} | Reward: {reward_model} | Maze Size: {maze_size} | "
                    f"Exceeded transient retry budget ({MAX_TRANSIENT_INFRA_RETRIES_PER_MAZE}). "
                    f"Counting this as a failed trial."
                )
                transient_retry_count = 0
            else:
                transient_retry_count = 0

            counter[solver_model][reward_model][maze_size]['tried'] += 1
            if solved == True:
                counter[solver_model][reward_model][maze_size]['success'] += 1

            print(
                f"Solver: {solver_model} | Reward: {reward_model} | Maze Size: {maze_size} | "
                f"{counter[solver_model][reward_model][maze_size]['tried']}/{TRIALS}"
            )

        solve_rate = (
            counter[solver_model][reward_model][maze_size]['success']
            / counter[solver_model][reward_model][maze_size]['tried']
        ) * 100.0
        solve_rates += [(maze_size, solve_rate)]

    return solver_model, reward_model, solve_rates


if __name__ == "__main__":
    _print_startup_config()
    counter = count_solved_mazes()

    for solver_model in MODEL_LIST:
        if solver_model not in counter:
            counter[solver_model] = {}

        for reward_model in REWARD_MODEL_LIST:
            if reward_model not in counter[solver_model]:
                counter[solver_model][reward_model] = {}

            for maze_size in MAZE_SIZES:
                if maze_size not in counter[solver_model][reward_model]:
                    counter[solver_model][reward_model][maze_size] = {}

                counter[solver_model][reward_model][maze_size].setdefault('tried', 0)
                counter[solver_model][reward_model][maze_size].setdefault('success', 0)

    with ThreadPoolExecutor(max_workers=MAX_PARALLEL_MODELS) as executor:
        model_pairs = [
            (solver_model, reward_model)
            for solver_model in MODEL_LIST
            for reward_model in REWARD_MODEL_LIST
        ]

        attempts_by_pair = {pair: 0 for pair in model_pairs}
        futures = set()
        future_to_pair = {}

        def submit_model_pair(solver_model: str, reward_model: str):
            pair = (solver_model, reward_model)
            attempts_by_pair[pair] += 1
            future = executor.submit(run_model, solver_model, reward_model)
            futures.add(future)
            future_to_pair[future] = pair

        for solver_model, reward_model in model_pairs:
            submit_model_pair(solver_model, reward_model)

        while futures:
            done, _ = wait(futures, return_when=FIRST_COMPLETED)

            for future in done:
                futures.remove(future)
                solver_model, reward_model = future_to_pair.pop(future)

                try:
                    solver_model, reward_model, solve_rates = future.result()
                except Exception as exc:
                    pair = (solver_model, reward_model)
                    if attempts_by_pair[pair] < MAX_MODEL_ATTEMPTS:
                        print(
                            f"Solver: {solver_model} | Reward: {reward_model} | "
                            f"Run crashed ({type(exc).__name__}: {exc}) | "
                            f"Retrying (attempt {attempts_by_pair[pair] + 1}/{MAX_MODEL_ATTEMPTS})..."
                        )
                        submit_model_pair(solver_model, reward_model)
                    else:
                        print(
                            f"Solver: {solver_model} | Reward: {reward_model} | "
                            f"Run crashed ({type(exc).__name__}: {exc}) | "
                            f"Giving up after {attempts_by_pair[pair]}/{MAX_MODEL_ATTEMPTS} attempts."
                        )
                    continue

                for maze_size, solve_rate in solve_rates:
                    print(
                        f"Solver: {solver_model} | Reward: {reward_model} | "
                        f"Maze Size: {maze_size} | Finished with solve rate: {solve_rate}"
                    )
                
    



