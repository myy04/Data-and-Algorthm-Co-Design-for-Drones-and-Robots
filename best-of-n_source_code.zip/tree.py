from solver_agent import SolverAgent
from deterministic_reward import DeterministicRewardAgent
from maze import Maze

import json
from pathlib import Path
from datetime import datetime


class Node:
    def __init__(self, maze_state, proposed_moves, reward):      
        self.maze_state = maze_state
        self.proposed_moves = proposed_moves
        self.reward = reward  

    def __repr__(self):
        ret = f"Proposed Moves: {self.proposed_moves}\n"
        ret += f"\nReward: {self.reward}\n"
        ret += self.maze_state['maze']
        return ret

class Tree:
    def __init__(self, solver_agent: str, reward_agent: str = "deterministic-v1"):
        self.solver_agent = SolverAgent(solver_agent, temperature=0.5)
        self.reward_agent = DeterministicRewardAgent(strategy_name=reward_agent)

        self.levels = []
        self.chosen_nodes = []

    def generate_level(self, maze_state, nodes = 3):
        new_level = []        
        for i in range(nodes):
            proposed_moves = self.solver_agent.ask_for_moves(maze_state)
            reward = self.reward_agent.ask_for_reward(maze_state, proposed_moves)
            new_level += [Node(maze_state, proposed_moves, reward)]
        
        self.levels += [new_level]
        return new_level

    def solve_maze(self, maze, max_depth = 10, save_results = True):
        for depth in range(max_depth):

            cur_maze_state = maze.get_state()
            next_nodes = self.generate_level(cur_maze_state)
            best_node = max(next_nodes, key = lambda node: node.reward)
            maze.make_moves(best_node.proposed_moves)   
            
            if maze.get_state()['goal reached']:
                break
        
        final_state = maze.get_state()
        if save_results:
            data = final_state
            data['solver agent'] = self.solver_agent.model
            data['reward agent'] = self.reward_agent.model 
            data['max depth'] = 10
            data['nodes per level'] = 3

            timestamp = datetime.now().strftime("%m%d%H%M%S")

            model_dir = Path(__file__).resolve().parent / "data"
            model_dir.mkdir(parents=True, exist_ok=True)

            output_file = f"{timestamp}_{self.solver_agent.model}_{self.reward_agent.model}.json"
            output_path = model_dir / output_file

            with output_path.open("w", encoding="utf-8") as f:
                json.dump(data, f, indent=2, ensure_ascii=False)

            print(f"Saved state to {output_path}")
        return final_state['goal reached']
    

if __name__ == "__main__":  
    maze = Maze()
    model_name = 'gemma3:12b-cloud'
    
    tree = Tree(model_name)
    tree.solve_maze(maze, save_results=True)

    if maze.get_state()['goal reached']:
        print("Solved")
    else: print("Not Solved")








